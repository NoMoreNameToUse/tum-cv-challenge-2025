% Main function entry point
GUI();
